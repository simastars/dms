<?php
// $con = new mysqli($host,$user,$password, $db);
function sanitized($con, $string){
	$string = mysqli_real_escape_string($con, trim($string));
	return $string;
}

function loaddata($con, $tablename){

	$sel = $con->query("SELECT * FROM $tablename");
	while($row=$sel->fetch_assoc()){
		extract($row);

		if($tablename=="subjects"){
			$data[] = array('<input type="checkbox" name="subj_id" id="subj_id" value='.$subj_id.'>',$subj_code,$subj_desc,$units);
		}
		else if($tablename=="year_level"){
			$data[] = array('<input type="checkbox" name="year_id" id="year_id" value='.$year_id.'>',$year_level,$section);
		}
		else if($tablename=="teachers"){
			$data[] = array('<input type="checkbox" name="teach_id" id="teach_id" value='.$teach_id.'>',$teach_no,$teach_fname.' '.$teach_mname.' '.$teach_lname,$teach_gender,$teach_degree,$teach_masteral);
		}
		else if($tablename=="students"){
			$data[] = array('<input type="checkbox" name="stud_id" id="stud_id" value='.$stud_id.'>',$stud_no,$stud_fname.' '.$stud_mname.' '.$stud_lname,$stud_gender,$stud_age.' years old');
		}

	}

	echo json_encode($data);
}

function validate($con, $string,$fieldname,$tablename){

	$val = $con->query("SELECT $fieldname from $tablename where $fieldname='$string' ");

	$num = $val->num_rows;

	if($num==0){
		echo 'available';
	}
	else{
		echo 'not';
	}
}

function validate_edit($con,$string,$id,$tablename,$fieldname,$fieldnameid){
	$val = $con->query("SELECT $fieldname FROM $tablename where $fieldname='$string' and $fieldnameid='$id' ");
	$num = $val->num_rows;

	if($num==1){
		echo 'available';
	}
	else{
		$val2 = $con->query("SELECT $fieldname from $tablename where $fieldname='$string' ");
		$num2 = $val2->num_rows;
		if($num2==1){
			echo 'not';
		}
		else{
			echo 'available';
		}
	}
}

function validate_section($con,$section,$grade){
	$sel = $con->query("SELECT * from year_level where year_level='$grade' and section='$section' ");
	$num = $sel->num_rows;
	if($num==1){
		echo 'failed';
	}
	else{
		echo 'available';
	}
}

function validate_section_edit($con,$section,$grade,$id){
	$sel = $con->query("SELECT * from year_level where year_level='$grade' and section='$section' and year_id='$id' ");
	$num = $sel->num_rows;
	if($num==1){
		echo 'available';
	}
	else{
		$sel = $con->query("SELECT * from year_level where year_level='$grade' and section='$section'");
		$num = $sel->num_rows;
		if($num==1){
			echo "failed";
		}
		else{
			echo "available";
		}
	}
}

function addquery($con,$data,$tablename){

	$fieldname = array_keys($data);

	$add = $con->query("INSERT INTO ".$tablename."(".implode(",", $fieldname).") VALUES('".implode("','", $data)."')");
}

function get_content($con,$id,$tablename,$fieldname){
	$sel = $con->query("SELECT * from $tablename where $fieldname='$id' ");

	while($row=$sel->fetch_assoc()){
		extract($row);

		if($tablename=="subjects"){
			$data = array('subj_id'=>$subj_id,'subj_code'=>$subj_code,'subj_desc'=>$subj_desc,'units'=>$units);
		}
		else if($tablename=="year_level"){
			$data = array('year_id'=>$year_id,'year_level'=>$year_level,'section'=>$section);
		}
		else if($tablename=="teachers"){
			$data = array('teach_id'=>$teach_id,'fname'=>$teach_fname,'mname'=>$teach_mname,'lname'=>$teach_lname,'gender'=>$teach_gender,'degree'=>$teach_degree,'masteral'=>$teach_masteral,'idnum'=>$teach_no);
		}
		else if($tablename=="students"){
			$data = array('stud_id'=>$stud_id,'fname'=>$stud_fname,'mname'=>$stud_mname,'lname'=>$stud_lname,'gender'=>$stud_gender,'age'=>$stud_age,'idnum'=>$stud_no);
		}
	}

	echo json_encode($data);
}

function editquery($con,$id,$fieldname,$data,$tablename){
	
	foreach ($data as $key => $value) {
		$val[] = "$key='$value' ";
	}
	$updatedata = implode(",", $val); 

	$edit = $con->query("UPDATE $tablename SET $updatedata WHERE $fieldname='$id' " );

	if($edit==true){
		echo 'success';
	}
	else{
		echo 'failed';
	}
}

function deletequery($con,$id,$tablename,$fieldname){
	$count = count($id);
	$var = 0;
	foreach ($id as $subject) {
		$del = $con->query("DELETE From $tablename where $fieldname='$subject' ");
		if($del==true){
			$var +=1;
		}
	}

	if($count==$var){
		echo 'success';
	}
	else{
		echo 'failed';
	}
}

function dropdown($con,$tablename){
	$sel = $con->query("SELECT * from $tablename");
			echo '<option value=0>Select Year Level</option>';
	while($row=$sel->fetch_assoc()){
		extract($row);

		echo '<option value='.$year_id.'>'.$year_level.'-'.$section.'</option>';
	}
}

function getstudentbyyear($con,$sy){
	$sel = $con->query("SELECT * from students");

	while($row=$sel->fetch_assoc()){
		extract($row);
		$sel2 = $con->query("SELECT * FROM student_year_level as syl join year_level as yl on syl.year_id=yl.year_id where syl.stud_id='$stud_id' and syl.schoolyear='$sy'");
		$num = $sel2->num_rows;
		if($num==0){
			$data[] = array('<input type="checkbox" name="stud_id" id="stud_id" value='.$stud_id.'>',$stud_no,$stud_fname.' '.$stud_mname.' '.$stud_lname);
		}
		else{
			while($row=$sel2->fetch_assoc()){
				extract($row);
				$data[] = array($year_level,$stud_no,$stud_fname.' '.$stud_mname.' '.$stud_lname);
			}
			
		}
	}
	echo json_encode($data);
}

function enroll_student($con,$year,$sy,$stud_id){

	foreach ($stud_id as $id) {
		$insert = $con->query("INSERT INTO student_year_level (stud_id,year_id,schoolyear) values ('$id','$year','$sy') ");
	}
}

function getstudentbyyearsy($con,$sy,$year){
	$sel = $con->query("SELECT * from student_year_level as syl join students as s on syl.stud_id=s.stud_id join year_level as yl on syl.year_id=yl.year_id where syl.schoolyear='$sy' and syl.year_id='$year' ");

	while($row=$sel->fetch_assoc()){
		extract($row);
		$data[] = array('<input type="checkbox" name="stud_id" id="stud_id" value='.$syl_id.'>',$stud_no,$stud_fname.' '.$stud_mname.' '.$stud_lname,$year_level);
		
	}
	echo json_encode($data);
}

function getdatachart($con,$sy){
	$sel = $con->query("SELECT * FROM year_level");

	while($row=$sel->fetch_assoc()){
		extract($row);
		$sel2 = $con->query("SELECT * from student_year_level where year_id='$year_id' and schoolyear='$sy' ");
		$num = $sel2->num_rows;
		$data[] = array('y'=>$year_level,'a'=>$num);
	}

	echo json_encode($data);
}

function get_year_name($con,$id){
	$sel = $con->query("SELECT * from year_level where year_id='$id' ");
	while($row=$sel->fetch_assoc()){
		extract($row);
		echo $year_level.'- '.$section;
	}
}

function add_subjects_grades($con,$grade,$subject){
	$count = count($subject);
	$var = 0;
	foreach ($subject as $subj_id) {
		$sel = $con->query("SELECT * from year_level_subject where subj_id='$subj_id' and year_id='$grade' ");
		$num = $sel->num_rows;
		if($num==0){
			$insert = $con->query("INSERT INTO year_level_subject (subj_id,year_id) values ('$subj_id','$grade') ");
			if($insert==true){
				$var +=1;
			}
		}
	}

	if($count==$var){
		echo 'success';
	}
	else{
		echo 'notcomplete';
	}
}

function load_year_subjects($con,$id){
	$sel = $con->query("SELECT * FROM year_level_subject as yls join subjects as s on yls.subj_id=s.subj_id  where yls.year_id='$id' ");

	while($row=$sel->fetch_assoc()){
		extract($row);
		$data[] = array('<input type="checkbox" name="yls_id" id="yls_id" value='.$yls_id.'>',$subj_code,$subj_desc);
	}
	echo json_encode($data);
}

function get_print_subjects($con,$id){
	$totalunits = 0;
	$sel = $con->query("SELECT * FROM year_level_subject as yls join subjects as s on yls.subj_id=s.subj_id  where yls.year_id='$id' ");
	while($row=$sel->fetch_assoc()){
		extract($row);
		echo '<tr>';
		echo '<td>'.$subj_code.'</td>';
		echo '<td>'.$subj_desc.'</td>';
		echo '<td>'.$units.'</td>';
		echo '</tr>';
		$totalunits += $units;
	}
	echo '<tr>';
	echo '<td></td>';
	echo '<td></td>';
	echo '<td></td>';
	echo '</tr>';

	echo '<tr>';
	echo '<th>Total Units</th>';
    echo '<td></td>';
	echo '<th>'.$totalunits.' units'.'</th>';
	echo '</tr>';
}

function get_print_students($con,$year,$sy){
	$sel = $con->query("SELECT * from student_year_level as syl join students as s on syl.stud_id=s.stud_id join year_level as yl on syl.year_id=yl.year_id where syl.schoolyear='$sy' and syl.year_id='$year' ");

	while($row=$sel->fetch_assoc()){
		extract($row);

		echo '<tr>';
		echo '<td>'.$stud_no.'</td>';
		echo '<td>'.$stud_fname.' '.$stud_mname.' '.$stud_lname.'</td>';
		echo '<td>'.$stud_gender.'</td>';
		echo '<td>'.$stud_age.'</td>';
		echo '</tr>';
	}
}

function generate_schedule($con,$sy,$year_id,$room){

	$time = array('7:30-8:30','8:30-9:30','10:00-11:00','11:00-12:00','1:00-2:00','2:00-3:00','3:30-4:30','7:30-8:30','8:30-9:30','10:00-11:00','11:00-12:00','1:00-2:00','2:00-3:00','3:30-4:30');
	$timecount = count($time);
	$mwf = "mwf";
	$tth = "tth";

	$val = $con->query("SELECT * FROM schedule as sched join year_level_subject as yls on sched.yls_id=yls.yls_id where  sched.schoolyear='$sy' and yls.year_id='$year_id' ");
	$num = $val->num_rows;


	if($num>0){
		echo '<div class="callout callout-danger">
                    <h4>Unable to generate Schedule</h4>
                    <p>This year level in this school year already have schedule try to view the schedule.</p>
                  </div>';
	}
	else{
		$yls = $con->query("SELECT * from year_level_subject where year_id='$year_id'");
		$x = 0;
		while($row=$yls->fetch_assoc()){
			extract($row);
			
			$sel = $con->query("SELECT * FROM schedule as sched join year_level_subject as yls on sched.yls_id=yls.yls_id where sched.days='$mwf' and sched.schoolyear='$sy' and yls.year_id='$year_id' ");
			$num = $sel->num_rows;
			if($num<7){
				$timehr = $time[$x];
				$ins = $con->query("INSERT INTO schedule (timehr,days,schoolyear,yls_id,room) VALUEs ('$timehr','$mwf','$sy','$yls_id','$room') ");
				$x +=1;
			}
			else{
				$timehr = $time[$x];
				$ins = $con->query("INSERT INTO schedule (timehr,days,schoolyear,yls_id,room) VALUEs ('$timehr','$tth','$sy','$yls_id','$room') ");
				$x +=1;
			}	
			
		}
		get_schedule($con,$sy,$year_id);		
	}
	
}

function get_schedule($con,$sy,$year_id){
	$sel = $con->query("SELECT * FROM schedule as sched join year_level_subject as yls on sched.yls_id=yls.yls_id join subjects as s on yls.subj_id=s.subj_id where sched.schoolyear='$sy' and yls.year_id='$year_id' ");
	echo '<table class="table table-bordered table-hover">';
	echo '<thead>
		  <tr>
		  <th>Time</th>
		  <th>Days</th>
		  <th>Subject</th>
		  <th>Teacher</th>
		  </tr>
		  </thead>';

	while($row=$sel->fetch_assoc()){
		extract($row);
		echo '<tr>';
		echo '<td>'.$timehr.'</td>';
		if($days=="mwf"){
			echo '<td>MWF</td>';
		}
		else{
			echo '<td>TTH</td>';
		}
		echo '<td>'.$subj_code.' '.$subj_desc.'</td>';
		$teach = $con->query("SELECT * FROM teachers");
		echo '<td><select id="selteacher" onchange="updateteacher('.$sched_id.')" >
			  <option value=0>Select Teacher</option>

		';
		while($row=$teach->fetch_assoc()){
			extract($row);
			echo '<option value='.$teach_id.'>'.$teach_fname.' '.$teach_mname.' '.$teach_lname.'</option>';
		}
		echo '</select></td>';

		echo '</tr>';

	}
	echo '</table>';
				
}
	


?>