<?php

require("functions.php");

$host = "localhost";
$user = "root";
$password = "";
$db = "db_records";

$con = new mysqli($host,$user,$password, $db);


$action = $_POST["action"];

switch ($action) {
	case 'load':
		$tablename = sanitized($con, $_POST['tablename']);
		loaddata($con,$tablename);
		break;
	case 'getdatachart':
		$sy = sanitized($con,$_POST['sy']);
		getdatachart($con,$sy);
		break;
	case 'validate':
		$string = sanitized($con,$_POST['string']);
		$fieldname = sanitized($con,$_POST['fieldname']);
		$tablename = sanitized($con,$_POST['tablename']);
		validate($con,$string,$fieldname,$tablename);
		break;
	case 'validate-edit':
		$string = sanitized($con,$_POST['string']);
		$id = sanitized($con,$_POST['id']);
		$fieldname = sanitized($con,$_POST['fieldname']);
		$tablename = sanitized($con,$_POST['tablename']);
		$fieldnameid = sanitized($con,$_POST['fieldnameid']);
		validate_edit($con,$string,$id,$tablename,$fieldname,$fieldnameid);
		break;
	case 'validate-section':
		$section = sanitized($con,$_POST['section']);
		$grade = sanitized($con,$_POST['grade']);
		validate_section($con,$section,$grade);
		break;
	case 'validate-section-edit':
		$section = sanitized($con,$_POST['section']);
		$grade = sanitized($con,$_POST['grade']);
		$id = sanitized($con,$_POST['id']);
		validate_section_edit($con,$section,$grade,$id);
		break;
	case 'get-content':
		$id = sanitized($con,$_POST['id']);
		$tablename = sanitized($con,$_POST['tablename']);
		$fieldname = sanitized($con,$_POST['fieldname']);
		get_content($con,$id,$tablename,$fieldname);
		break;
	case 'delete':
		$tablename = sanitized($con,$_POST['tablename']);
		$fieldname = sanitized($con,$_POST['fieldnameid']);
		deletequery($con,$_POST['id'],$tablename,$fieldname);
		break;
	case 'add-subject':
		$code = sanitized($con,$_POST['code']);
		$desc = sanitized($con,$_POST['desc']);
		$units = sanitized($con,$_POST['units']);
		$data = array('subj_code'=>$code,'subj_desc'=>$desc,'units'=>$units);
		$tablename = 'subjects';
		addquery($con,$data,$tablename);
		echo mysqli_insert_id($con);
		break;
	case 'edit-subject':
		$code = sanitized($con,$_POST['code']);
		$desc = sanitized($con,$_POST['desc']);
		$units = sanitized($con,$_POST['units']);
		$id = sanitized($con,$_POST['id']);
		$data = array('subj_code'=>$code,'subj_desc'=>$desc,'units'=>$units);
		$tablename = "subjects";
		$fieldname = "subj_id";
		editquery($con,$id,$fieldname,$data,$tablename);
		break;
	case 'add-year-level':
		$year = sanitized($con,$_POST['year']);
		$section = sanitized($con,$_POST['section']);
		$data = array('year_level'=>$year,'section'=>$section);
		$tablename = 'year_level';
		addquery($con,$data,$tablename);
		echo mysqli_insert_id($con);
		break;
	case 'edit-year-level':
		$year = sanitized($con,$_POST['year']);
		$section = sanitized($con,$_POST['section']);
		$id = sanitized($con,$_POST['id']);
		$data = array('year_level'=>$year,'section'=>$section);
		$tablename = "year_level";
		$fieldname = "year_id";
		editquery($con,$id,$fieldname,$data,$tablename);
		break;
	case 'add-teacher':
		$idnum = sanitized($con,$_POST['idnum']);
		$fname = sanitized($con,$_POST['fname']);
		$mname = sanitized($con,$_POST['mname']);
		$lname = sanitized($con,$_POST['lname']);
		$gender = sanitized($con,$_POST['gender']);
		$degree = sanitized($con,$_POST['degree']);
		$masteral = sanitized($con,$_POST['masteral']);
		$data = array('teach_no'=>$idnum,'teach_fname'=>$fname,'teach_mname'=>$mname,'teach_lname'=>$lname,'teach_degree'=>$degree,'teach_gender'=>$gender,'teach_masteral'=>$masteral);
		$tablename = 'teachers';
		addquery($con,$data,$tablename);
		echo mysqli_insert_id($con);
		break;
	case 'edit-teacher':
		$idnum = sanitized($con,$_POST['idnum']);
		$fname = sanitized($con,$_POST['fname']);
		$mname = sanitized($con,$_POST['mname']);
		$lname = sanitized($con,$_POST['lname']);
		$gender = sanitized($con,$_POST['gender']);
		$degree = sanitized($con,$_POST['degree']);
		$masteral = sanitized($con,$_POST['masteral']);
		$id = sanitized($con,$_POST['id']);
		$data = array('teach_no'=>$idnum,'teach_fname'=>$fname,'teach_mname'=>$mname,'teach_lname'=>$lname,'teach_degree'=>$degree,'teach_masteral'=>$masteral,'teach_gender'=>$gender);
		$tablename = "teachers";
		$fieldname = "teach_id";
		editquery($con,$id,$fieldname,$data,$tablename);
		break;
	case 'add-student':
		$idnum = sanitized($con,$_POST['idnum']);
		$fname = sanitized($con,$_POST['fname']);
		$mname = sanitized($con,$_POST['mname']);
		$lname = sanitized($con,$_POST['lname']);
		$gender = sanitized($con,$_POST['gender']);
		$age = sanitized($con,$_POST['age']);
		$data = array('stud_no'=>$idnum,'stud_fname'=>$fname,'stud_mname'=>$mname,'stud_lname'=>$lname,'stud_age'=>$age,'stud_gender'=>$gender);
		$tablename = 'students';
		addquery($con,$data,$tablename);
		echo mysqli_insert_id($con);
		break;
	case 'edit-student':
		$idnum = sanitized($con,$_POST['idnum']);
		$fname = sanitized($con,$_POST['fname']);
		$mname = sanitized($con,$_POST['mname']);
		$lname = sanitized($con,$_POST['lname']);
		$gender = sanitized($con,$_POST['gender']);
		$id = sanitized($con,$_POST['id']);
		$age = sanitized($con,$_POST['age']);
		$data = array('stud_no'=>$idnum,'stud_fname'=>$fname,'stud_mname'=>$mname,'stud_lname'=>$lname,'stud_age'=>$age,'stud_gender'=>$gender);
		$tablename = 'students';
		$fieldname = "stud_id";
		editquery($con,$id,$fieldname,$data,$tablename);
		break;
	case 'dropdown':
		$tablename = sanitized($con,$_POST['tablename']);
		dropdown($con,$tablename);
		break;
	case 'getstudentbyyear':
		$sy = sanitized($con,$_POST['sy']);
		getstudentbyyear($con,$sy);
		break;
	case 'enroll-student':
		$year = sanitized($con,$_POST['year']);
		$sy = sanitized($con,$_POST['sy']);
		enroll_student($con,$year,$sy,$_POST['stud_id']);
		getstudentbyyear($con,$sy);
		break;
	case 'getstudentbyyearsy':
		$sy = sanitized($con,$_POST['sy']);
		$year = sanitized($con,$_POST['year']);
		getstudentbyyearsy($con,$sy,$year);
		break;
	case 'get-year-name':
		$id = sanitized($con,$_POST['id']);
		get_year_name($con,$id);
		break;
	case 'add-subjects-grades':
		$grade = sanitized($con,$_POST['grade']);
		add_subjects_grades($con,$grade,$_POST['subject']);
		break;
	case 'loadyearsubjects':
		$id = sanitized($con,$_POST['id']);
		load_year_subjects($con,$id);
		break;
	case 'generate-schedule':
		$sy=sanitized($con,$_POST['sy']);
		$year_id = sanitized($con,$_POST['year']);
		$room = sanitized($con,$_POST['room']);
		generate_schedule($con,$sy,$year_id,$room);
		break;


}

?>