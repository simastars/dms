<?php include "../templates/templates.php"; 
        headertemplate('Dashboard | Administrator'); ?>

  <body class="skin-green">
    <div class="wrapper">
      
     <?php navbar('dashboard'); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
          </h1>
        </section>

       <section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="box">
                 <div class="box-header with-border">
                  <h3 class="box-title"><input type="text" name="sy" id="sy" placeholder="Input year"></h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-toggle="tooltip" title="Minimize" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-toggle="tooltip" title="Close" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="row">
                    <div class="col-md-12">
                      <p class="text-center">
                        <strong id="year"></strong>
                      </p>
                      <div class="chart-responsive">
                        <!-- Sales Chart Canvas -->
                        <div id="bar-chart" height="180"></div>
                      </div><!-- /.chart-responsive -->
                    </div>
                  </div>
                </div>
              </div>
              
              </div>

            </div>
          </div>
       </section>   
    
      </div><!-- /.content-wrapper -->

     <?php footertemplate();?>

     <script type="text/javascript">
           var chart = Morris.Bar({
          element: 'bar-chart',
          data: [0,0],
          xkey: 'y',
          ykeys: ['a'],
          labels: ['No. of Students']
        });

        $("#sy").forceNumeric();

        $("#sy").keyup(function(){
          var sy =  $("#sy").val();
          var year = sy * 2/2+1;
          var schoolyear = sy+'-'+year;
          var datastring = 'action=getdatachart&sy='+schoolyear;
          if(sy==''){
            $("#year").html(' ');
          }
          else{
            $("#year").html('School Year '+sy+'-'+year);
            $.ajax({
              type:"POST",
              url:"../php/crud.php",
              dataType:'json',
              data:datastring,
              success: function(data){
                chart.setData(data);
              }
            });
          }
            return false;
        });

     </script>
  </body>
</html>